#!/usr/bin/python
# Filename: mymodule_demo.py

import mumodule

mumodule.sayHi()

print 'Version', mumodule.version
